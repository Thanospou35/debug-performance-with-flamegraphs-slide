import allBugData from "./bugs";

export const allBugs = [...allBugData];
